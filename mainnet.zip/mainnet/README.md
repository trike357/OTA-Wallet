
# OTR Chain Mainnet

This folder contains the mainnet configuration for the OTR blockchain.

## Contents
- genesis.json (finalized)
- config.toml
- Validator onboarding instructions

Mainnet is currently in preparation. This folder will be updated for production nodes.
