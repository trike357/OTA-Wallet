
# OTR Chain Testnet

This folder contains the testnet configuration for the OTR blockchain.

## Contents
- genesis.json
- config.toml
- Validator setup script
- Docker support for quick deployment

## Usage
Run the node using the provided docker-compose or manually with `otr-chaind`.

